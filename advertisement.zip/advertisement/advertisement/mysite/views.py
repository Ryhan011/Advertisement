from django.shortcuts import render

def login_view(request):
    return render(request, 'login.html')

def signup_view(request):
    return render(request, 'signup.html')

def manage_ads_view(request):
    return render(request, 'manage_ads.html')

def home_view(request):
    return render(request, 'home.html')

def advertisement_details_view(request):
    return render(request, 'advertisement_details.html')
