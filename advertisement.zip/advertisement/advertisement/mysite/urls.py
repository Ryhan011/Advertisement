from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login, name='login'),
    path('signup/', views.signup, name='signup'),
    path('manage_ads/', views.manage_ads, name='manage_ads'),
    path('advertisement_details/<int:advertisement_id>/', views.advertisement_details, name='advertisement_details'),
]
